######
 IDEs
######

.. toctree::
   :hidden:

   visual-studio-code

Here you can find instructions on how to effectively use common IDEs for php-src development.
